# FastTD3 algorithm
