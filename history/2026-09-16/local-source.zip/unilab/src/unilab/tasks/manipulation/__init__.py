"""Manipulation task packages."""
